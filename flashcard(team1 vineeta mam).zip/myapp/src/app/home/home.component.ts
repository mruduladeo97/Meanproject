import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  public sessionid = sessionStorage.getItem("sessionid");

   public data = {
    productname:"flipcart",
    couponcode :"B222",
    discount : "30%",
    id: this.sessionid
  } 

  constructor(private router:Router,private http: HttpClient) { }

  ngOnInit(): void {
  }
  async dominos(){
    const url = 'http://localhost:3000/addtocart';
  
      await this.http.post(url, this.data).toPromise();
 
  }
}
