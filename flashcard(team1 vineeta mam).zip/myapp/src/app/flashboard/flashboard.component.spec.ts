import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FlashboardComponent } from './flashboard.component';

describe('FlashboardComponent', () => {
  let component: FlashboardComponent;
  let fixture: ComponentFixture<FlashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FlashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FlashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
