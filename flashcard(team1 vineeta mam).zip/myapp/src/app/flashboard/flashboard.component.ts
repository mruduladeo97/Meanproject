import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-flashboard',
  templateUrl: './flashboard.component.html',
  styleUrls: ['./flashboard.component.css']
})
export class FlashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
