import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  public uiInvalidCredential = false;
  

  public fbFormGroup = this.fb.group({
    email: ['', Validators.required],
    pwd: ['', Validators.required],
    });

    constructor(private router:Router,private fb: FormBuilder,    private http: HttpClient) { }

  ngOnInit(): void {
  }
  navigateTo(register){
    this.router.navigate([register])
  }
  async loginProcessHere() {
    const data = this.fbFormGroup.value;

    const url = 'http://localhost:3000/checkuser';
    const result: any = await this.http.post(url, data).toPromise();
    if (result[0].id) {
      sessionStorage.setItem("sid","true")
      sessionStorage.setItem("sessionid",result[0].id)
    this.router.navigate(['dashboard']);
    }else {
      this.uiInvalidCredential = true;
    }

  }
}
