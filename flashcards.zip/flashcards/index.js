require('./dist/angular-flash');
module.exports = 'ngFlash';
