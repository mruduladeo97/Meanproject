const express = require("express");
const cors = require("cors");

const app = express();


app.use(cors()); // unblocking cors policy
app.use(express.json()); 

const dbadduser = require("./dbconn");

app.post("/add", async (req, res) => {
  try {
    const input = req.body; 

    await dbadduser.addUser(input);
    res.json({ message: "success post" });
  } catch (err) {
    res.json({ message: "failure post" });
  }
});


app.post("/checkuser", async (req, res) => {
  try {
    const input = req.body; 

   let result = await dbadduser.checkUser(input);
    res.json(result);
  } catch (err) {
    res.json({ opr:false });
  }
});

app.post("/checkmail", async (req, res) => {
  try {
    const input = req.body; 
console.log(input)
    await dbadduser.checkmail(input);
    res.json({ opr:true });
  } catch (err) {
    res.json({ opr:false });
  }
});

app.post("/addtocart", async (req, res) => {
  try {
    const input = req.body; 

    await dbadduser.addtocart(input);
    res.json({ message: "success post" });
  } catch (err) {
    res.json({ message: "failure post" });
  }
});

app.get("/getproduct", async (req, res) => {
  try {
   let result = await dbadduser.getproduct();
    res.json(result);
  } catch (err) {
    res.json({ opr:false });
  }
});

// started teh server.
app.listen(3000);